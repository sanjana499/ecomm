module.exports = [
"[project]/.next-internal/server/app/api/country/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_country_route_actions_2bc183da.js.map