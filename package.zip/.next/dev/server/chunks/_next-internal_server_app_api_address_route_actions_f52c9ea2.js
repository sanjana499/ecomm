module.exports = [
"[project]/.next-internal/server/app/api/address/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_address_route_actions_f52c9ea2.js.map