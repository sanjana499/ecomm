module.exports = [
"[project]/.next-internal/server/app/master/categories/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_master_categories_page_actions_35b2c211.js.map