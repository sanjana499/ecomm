module.exports = [
"[project]/.next-internal/server/app/product/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_product_page_actions_07a04afa.js.map