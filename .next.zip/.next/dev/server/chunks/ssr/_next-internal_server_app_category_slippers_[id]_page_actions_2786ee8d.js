module.exports = [
"[project]/.next-internal/server/app/category/slippers/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_category_slippers_%5Bid%5D_page_actions_2786ee8d.js.map